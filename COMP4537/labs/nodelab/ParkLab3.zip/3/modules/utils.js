function getDate() {
    const now = new Date();
    return now.toString();
}

module.exports = { getDate };
