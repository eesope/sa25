const math = require('./math.js');
console.log(`Hello Saeyoung. Typically, 1 + 1 is ${math.add(1, 1)}`);
console.log(`Hello Saeyoung. Typically, 1 - 1 is ${math.subtract(1, 1)}`);
